import UIKit

class AnnouncementsViewController: UITableViewController {
    private let announcements = CampusAnnouncement.sampleAnnouncements

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Campus Announcements"
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return announcements.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "AnnouncementCell", for: indexPath) as? AnnouncementCell else { return UITableViewCell() }
        cell.configure(with: announcements[indexPath.row])
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "ShowAnnouncementDetailSegue", sender: announcements[indexPath.row])
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ShowAnnouncementDetailSegue",
           let destination = segue.destination as? DetailViewController,
           let selected = sender as? CampusAnnouncement {
            destination.announcement = selected
        }
    }
}
