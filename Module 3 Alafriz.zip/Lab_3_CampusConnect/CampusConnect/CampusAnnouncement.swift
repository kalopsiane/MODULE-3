import Foundation

struct CampusAnnouncement {
    let title: String
    let date: String
    let category: String
}

extension CampusAnnouncement {
    static let sampleAnnouncements: [CampusAnnouncement] = [
        CampusAnnouncement(title: "Enrollment Period Extended", date: "Aug 03, 2026", category: "Registrar"),
        CampusAnnouncement(title: "Library Hours Extended", date: "Aug 05, 2026", category: "Library"),
        CampusAnnouncement(title: "Career Fair 2026", date: "Aug 10, 2026", category: "Career Center"),
        CampusAnnouncement(title: "Student Council Elections", date: "Aug 14, 2026", category: "Student Affairs"),
        CampusAnnouncement(title: "WI-FI Maintenance Notice", date: "Aug 16, 2026", category: "IT Services"),
        CampusAnnouncement(title: "Midterm Exam", date: "Oct 5, 2026", category: "Higher Education Office")
    ]
}
